package com.ibm.car.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.car.bean.Car;

@Repository
public interface CarRepository extends CrudRepository<Car, Integer> {

}
