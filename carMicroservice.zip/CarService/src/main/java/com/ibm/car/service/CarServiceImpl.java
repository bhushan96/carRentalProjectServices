package com.ibm.car.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.car.bean.Car;
import com.ibm.car.repository.CarRepository;

@Service
public class CarServiceImpl implements CarService {
	
	@Autowired
	CarRepository dao;
	
	@Override
	public Iterable<Car> getAllCars() {
	
		return dao.findAll();
	}

	@Override
	public Optional<Car> getCarById(int id) {
		return dao.findById(id);
	}

	
	

	
}
