package com.ibm.car.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.car.bean.Car;
import com.ibm.car.service.CarService;

@RestController
@RequestMapping("/cars")
public class CarController {

	@Autowired
	CarService service;

	@RequestMapping("")
	Iterable<Car> getAllCars(){
		
		return service.getAllCars();
		
	}
	
	
	@RequestMapping("/{id}")
	Optional<Car> getCarById(@PathVariable int id) {
		
		return service.getCarById(id);
	}

}
