package com.ibm.car.service;

import java.util.Optional;

import com.ibm.car.bean.Car;

public interface CarService {

	Iterable<Car> getAllCars();

	Optional<Car> getCarById(int id);


}
