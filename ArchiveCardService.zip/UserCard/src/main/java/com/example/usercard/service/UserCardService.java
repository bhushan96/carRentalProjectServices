package com.example.usercard.service;

import com.example.usercard.bean.UserCard;


public interface UserCardService {
	Iterable<UserCard> getAllUserCards();

}
