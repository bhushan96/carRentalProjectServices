package com.example.usercard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserCardService {

	public static void main(String[] args) {
		SpringApplication.run(UserCardService.class, args);
		
	}

}
