package com.example.usercard.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.example.usercard.bean.UserCard;;

@Repository
public interface UserCardRepository extends CrudRepository<UserCard, String> {
	

}
