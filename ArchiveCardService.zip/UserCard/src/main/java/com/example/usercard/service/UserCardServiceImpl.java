package com.example.usercard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.usercard.bean.UserCard;
import com.example.usercard.repository.UserCardRepository;
import com.example.usercard.service.UserCardService;


@Service
public class UserCardServiceImpl implements UserCardService  {

	@Autowired
UserCardRepository dao;
	
	@Override
	public Iterable<UserCard> getAllUserCards() {
	
		return dao.findAll();
	}

	
	}


