package com.example.usercard.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_cards")
public class UserCard {
	@Id
	String accountNumber;
	Integer expiryMonth;
	Integer expiryYear;
	String userName;
	Integer cvv;
	public UserCard() {
		
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public UserCard(int expiryMonth, int expiryYear,int cvv, String userName) {
		
		this.expiryMonth = expiryMonth;
		this.expiryYear = expiryYear;
		this.userName = userName;
		this.cvv=cvv;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getExpiryMonth() {
		return expiryMonth;
	}
	public void setExpiry_Month(int expiryMonth) {
		this.expiryMonth = expiryMonth;
	}
	public int getExpiry_Year() {
		return expiryYear;
	}
	public void setExpiry_Year(int expiryYear) {
		this.expiryYear = expiryYear;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	

}
