package com.example.usercard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.usercard.bean.UserCard;
import com.example.usercard.service.UserCardServiceImpl;


@RestController

public class UserCardController {
	
	@Autowired
	UserCardServiceImpl service;
	
	
		@RequestMapping("/userCardsDetails")
		Iterable<UserCard> getAllUserDetails(){
			
			return service.getAllUserCards();
			
		}
		

}