package com.ibm.user.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.ibm.user.bean.UserDetails;

public interface UserDetailsRepository extends CrudRepository<UserDetails, String> {
	
	
	Optional<UserDetails> findByEmailAndPassword(String email,String password);
	
}
